# Website Meteor 🌠

Project website sederhana bertema meteor dan luar angkasa.

## Fitur
- Halaman utama
- Galeri sederhana
- Desain dark mode

## Cara Menjalankan
Buka file `index.html` di browser.
